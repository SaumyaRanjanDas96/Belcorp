package GenericLib;

import net.serenitybdd.core.pages.PageObject;

public class CartActions extends PageObject {

    public void goPayCart(){
        $("//div[@class='actions']/child::button[contains(text(),'Ir a pagar')]").click();
    }

}
