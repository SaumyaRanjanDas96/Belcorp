package GenericLib;

import net.thucydides.core.pages.PageObject;

import java.util.Iterator;
import java.util.Set;

public class FBuserLoginActions extends PageObject {
    public void clickOnLoginwithFbButton(){
        $("#loginFB").click();
        waitFor("//div[@class='fb_content clearfix']/span");
        Set<String> allwh = getDriver().getWindowHandles();
        Iterator<String> it = allwh.iterator();
        String parentwh = it.next();
        String childwh = it.next();
        getDriver().switchTo().window(childwh);

            $("(//div[@class='clearfix form_row']/div/input)[1]").type("ec.esc2.mto.fb@gmail.com");
            $("(//div[@class='clearfix form_row']/div/input)[2]").type("Belcorp123");
        getDriver().switchTo().window(parentwh);
        }

    }

