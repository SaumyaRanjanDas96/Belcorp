package GenericLib;

import net.serenitybdd.core.pages.PageObject;


public class HomePageActions extends PageObject {

    public void MaquiljeLink(){
        $("div#esika-01 a").click();
    }

    public void clickPerfumeLink(){
        $("//a[@title='Perfumes']").click();

    }

}