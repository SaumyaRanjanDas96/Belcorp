package GenericLib;

import net.thucydides.core.pages.PageObject;

public class PdpPageActions extends PageObject {

    public void clickOnAddTocartButton(){
      $("#addToCartButton").click();
    }
    public void ClickOnGopayButton(){

        $("(//a[@class='btn btn-black btn-block add-to-cart-button'])[1]").click();

    }

}
