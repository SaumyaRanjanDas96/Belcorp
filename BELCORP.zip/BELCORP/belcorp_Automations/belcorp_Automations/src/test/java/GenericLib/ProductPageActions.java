package GenericLib;

import net.thucydides.core.pages.PageObject;

public class ProductPageActions extends PageObject {

    public void clickOnFirstProduct(){

        $("(//a[@class='name'])[1]").click();

    }

}
