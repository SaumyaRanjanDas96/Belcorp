package GenericLib;

import net.serenitybdd.screenplay.ensure.Ensure;
import net.thucydides.core.pages.PageObject;

public class ShippingAddressActions extends PageObject {

    public void verfifyCheckoutBanner(){
        String actualtext=$("(//div[@class='content']/strong)[2]").getText();
        String expectedtext="¿Necesitas ayuda en tu proceso de pago?";
        Ensure.that(actualtext).contains(expectedtext);

    }

    public void verifyBanner(){
        String bannertext= $("(//div[@class='alert alert-info help-payment-alert'])[2]/span").getText();
        Ensure.that(bannertext).contains("Necesitas ayuda en tu proceso de pago? Escríbenos ");
    }

}
