package GenericLib;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class UserDetailsActions extends PageObject {

    public void guestUserDetails(){
        $("//input[@id='guest.firstName']").sendKeys("Photon");
        $("//input[@id='guest.lastName']").sendKeys("Test");
        $("//input[@id='guest.email']").sendKeys("photontest@endtest-mail.io");
    }

    public void GuestLoginButton(){
        $("//button[contains(text(),'Continuar como invitado')]").click();
    }

    public void registeredUserDetails(){
        $("//input[@id='j_username']").sendKeys("test_user_92792380@testuser.com");
        $("//input[@id='j_password']").sendKeys("Qatest2042");
    }

    public void registeredLoginButton(){
        $(By.xpath("//button[@class='loginBtn btn btn-black btn-block mt-15']")).click();
    }

    public void termsandConditions(){
        $("//div[@class='custom-item-checkbox']/input[@id='guest.belcorpToC']").click();
    }
}

