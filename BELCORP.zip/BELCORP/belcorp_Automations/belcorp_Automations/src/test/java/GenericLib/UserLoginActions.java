package GenericLib;

import net.serenitybdd.core.pages.PageObject;

public class UserLoginActions extends PageObject {

    public void loginIcon(){
        $("li.liOffcanvas.bicHeaderLinks-container > a > img").click();
    }

    public void fillRegisteredUserDetails(){
        $("input#j_username").sendKeys("test_user_92792380@testuser.com");
        $("input#j_password").sendKeys("Qatest2042");
        $("//button[contains(text(),'Iniciar sesión')]").click();
    }

}
