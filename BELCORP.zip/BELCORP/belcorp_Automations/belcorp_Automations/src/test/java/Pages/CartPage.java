package Pages;

import GenericLib.CartActions;
import net.thucydides.core.annotations.Step;

public class CartPage extends CartActions {

    @Step
    public void clickOnGoPayButtonCart(){
       goPayCart();
    }

}
