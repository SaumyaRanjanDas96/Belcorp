package Pages;

import GenericLib.UserDetailsActions;
import net.thucydides.core.annotations.Step;


public class CheckoutLoginPage extends UserDetailsActions {

    @Step
    public void FillGuestUserDetails(){
        guestUserDetails();
    }

    @Step
    public void clickOnGuestUserLoginButton(){
        GuestLoginButton();
    }

    @Step
    public void fillsRegisteredUserDetails(){
        registeredUserDetails();
    }
    @Step
    public void clickOnRegisteredUserLoginButton(){
        registeredLoginButton();
    }

    @Step
    public void clickOnTermsandCondition(){
       termsandConditions();
    }

}
