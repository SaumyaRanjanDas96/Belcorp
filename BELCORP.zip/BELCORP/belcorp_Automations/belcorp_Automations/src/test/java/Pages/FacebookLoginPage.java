package Pages;

import GenericLib.FBuserLoginActions;
import net.thucydides.core.annotations.Step;

public class FacebookLoginPage {
    FBuserLoginActions fBuserLoginActions;
    @Step
    public void loginWithFbUser(){
        fBuserLoginActions.clickOnLoginwithFbButton();
    }
}
