package Pages;

import GenericLib.HomePageActions;
import net.thucydides.core.annotations.Step;
import starter.navigation.CyzoneHomePageCOEcom;
import starter.navigation.EsikaHomePageMXmto;
import starter.navigation.EsikaHomePageMexicoEcom;

public class HomePage {
    HomePageActions homePageActions;
    EsikaHomePageMexicoEcom esikahomepage;
    CyzoneHomePageCOEcom cyzoneHomePageCOEcom;
    EsikaHomePageMXmto esikaHomePageMXmto;

    @Step
    public void openCyzoneEcomColombiaUrl(){
        cyzoneHomePageCOEcom.open();
    }

    @Step
    public void openEsikaEcomMexicoUrl(){
        esikahomepage.open();
    }

    @Step
    public void openEsikaMexicoMtoUrl(){
        esikaHomePageMXmto.open();
    }

    @Step
    public void clickOnPerfumeSection(){
        homePageActions.clickPerfumeLink();
    }

    @Step
    public void clickOnMaquiljeSection(){
        homePageActions.MaquiljeLink();
    }


}
