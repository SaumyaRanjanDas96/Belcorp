package Pages;

import net.thucydides.core.annotations.Step;
import GenericLib.PdpPageActions;

public class PDPPage {
    PdpPageActions pdppageaction;

    @Step
    public void clickOnAddToCartButton(){
    pdppageaction.clickOnAddTocartButton();

    }
    @Step
    public void clickOnGopayButton(){
    pdppageaction.ClickOnGopayButton();
    }
}
