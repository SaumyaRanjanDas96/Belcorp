package Pages;

import net.thucydides.core.annotations.Step;
import GenericLib.ProductPageActions;

public class ProductPage {
  ProductPageActions productpageAction;
  HomePage homePage;


    @Step
    public void clickOnFirstProduct(){

    productpageAction.clickOnFirstProduct();
    }

}
