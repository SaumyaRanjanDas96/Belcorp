package Pages;

import GenericLib.ShippingAddressActions;
import net.thucydides.core.annotations.Step;

public class ShippingAddressPage {
    ShippingAddressActions shippingAddressActions;

    @Step
    public void verifyCheckoutBanner(){
     shippingAddressActions.verfifyCheckoutBanner();
    }

    @Step
    public void ShippingAddressBanner(){
        shippingAddressActions.verifyBanner();
    }


}
