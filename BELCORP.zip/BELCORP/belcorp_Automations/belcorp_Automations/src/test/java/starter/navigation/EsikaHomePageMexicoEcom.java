package starter.navigation;

import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.pages.PageObject;
@DefaultUrl("https://s1-esika.tiendabelcorp.com/mx/")
public class EsikaHomePageMexicoEcom extends PageObject {
}
