package starter.stepdefinitions;

import Pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class C3462 {
    @Steps
    HomePage homePage;
    @Steps
    ProductPage productPage;
    @Steps
    PDPPage pdpPage;
    @Steps
    CartPage cartPage;
    @Steps
    CheckoutLoginPage guest;
    @Steps
    ShippingAddressPage shippingAddressPage;

    @Given("Go to Cyzone ECOM website")
    public void Go_to_Cyzone_ECOM_website() {
        homePage.openCyzoneEcomColombiaUrl();
        homePage.clickOnPerfumeSection();
    }

    @When("Click on first product under perfumes,click on go pay")
    public void click_on_first_product_under_perfumes_click_on_go_pay() {
         productPage.clickOnFirstProduct();
         pdpPage.clickOnAddToCartButton();
         pdpPage.clickOnGopayButton();
        cartPage.clickOnGoPayButtonCart();

          }

    @And("Login as Guest User")
    public void LoginasGuestUser() {

        guest.guestUserDetails();
        guest.termsandConditions();
        guest.GuestLoginButton();
    }

    @Then("Validte checkout Banner")
    public void validte_checkout_banner() {

        shippingAddressPage.verifyCheckoutBanner();
    }
}