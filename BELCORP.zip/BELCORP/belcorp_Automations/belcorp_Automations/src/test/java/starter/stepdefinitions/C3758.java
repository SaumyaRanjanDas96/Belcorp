package starter.stepdefinitions;

import Pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class C3758 {

    @Steps
    HomePage homePage;
    @Steps
    ProductPage productPage;
    @Steps
    PDPPage pdpPage;
    @Steps
    CartPage cartPage;
    @Steps
    CheckoutLoginPage guest;
    @Steps
    ShippingAddressPage shippingAddressPage;

    @Given("Go to the Experience")
    public void goToTheExperience() {
        homePage.openEsikaEcomMexicoUrl();
        homePage.clickOnMaquiljeSection();
    }

    @When("Add a product to the bag")
    public void addAProductToTheBag() {
        productPage.clickOnFirstProduct();
        pdpPage.clickOnAddToCartButton();
        pdpPage.clickOnGopayButton();
        cartPage.clickOnGoPayButtonCart();
    }

    @And("Go to Pay Login as: guest")
    public void goToPayLoginAsGuest() {
        guest.FillGuestUserDetails();
        guest.clickOnGuestUserLoginButton();
    }

    @Then("that the banner has the following content Do you need help with your payment process? Write to us at consultacomprasmx@belcorp.biz")
    public void thatTheBannerHasTheFollowingContentDoYouNeedHelpWithYourPaymentProcessWriteToUsAtConsultacomprasmxBelcorpBiz() {
       shippingAddressPage.ShippingAddressBanner();
    }


}
