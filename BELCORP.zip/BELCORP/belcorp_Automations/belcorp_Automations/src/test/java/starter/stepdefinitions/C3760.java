package starter.stepdefinitions;

import Pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class C3760 {

    @Steps
    HomePage homepage;
    @Steps
    ProductPage productpage;
    @Steps
    CartPage cartPage;
    @Steps
    PDPPage pdpPage;

    @Steps
    CheckoutLoginPage guest;

    @Given("Go to Esika ECOM website")
    public void goToEsikaECOMWebsite() {
        homepage.openEsikaEcomMexicoUrl();
        homepage.clickOnPerfumeSection();

    }

    @When("Click on any product,click on go pay")
    public void clickOnAnyProductClickOnGoPay() {
        productpage.clickOnFirstProduct();
        pdpPage.clickOnAddToCartButton();
        pdpPage.clickOnGopayButton();
        cartPage.clickOnGoPayButtonCart();
    }

    @And("Login Guest User")
    public void loginAsGuestUser() {
        guest.FillGuestUserDetails();
        guest.clickOnGuestUserLoginButton();
    }

    @Then("Validte Banner")
    public void validteBanner() {
    }

    @And("Login as registered User User")
    public void loginAsRegisteredUserUser() {

    }
}
