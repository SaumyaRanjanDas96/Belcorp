package starter.stepdefinitions;

import Pages.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;


public class C3779 {

    @Steps
    HomePage homepage;
    @Steps
    ProductPage productpage;
    @Steps
    CartPage cartPage;
    @Steps
    PDPPage pdpPage;
    @Steps
    CheckoutLoginPage registered;
    @Steps
    ShippingAddressPage shippingAddressPage;

    @Given("Go to Experience:")
    public void goToExperience() {
        homepage.openEsikaMexicoMtoUrl();
        homepage.clickOnPerfumeSection();
    }

    @When("Add a product to cart")
    public void addAProductToCart() {
        productpage.clickOnFirstProduct();
        pdpPage.clickOnAddToCartButton();
        pdpPage.clickOnGopayButton();
        cartPage.clickOnGoPayButtonCart();
    }

    @And("Go to Pay Login as: existing account")
    public void goToPayLoginAsExistingAccount() {
        registered.fillsRegisteredUserDetails();
        registered.registeredLoginButton();
        cartPage.clickOnGoPayButtonCart();
    }


    @Then("Visualize that the banner has the following content. Do you need help with your payment process? Write to us at")
    public void visualizeThatTheBannerHasTheFollowingContentDoYouNeedHelpWithYourPaymentProcessWriteToUsAt() {
        shippingAddressPage.ShippingAddressBanner();
    }


}
