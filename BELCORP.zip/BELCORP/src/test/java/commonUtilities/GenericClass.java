package commonUtilities;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import platforms.PortalPlatform;

public class GenericClass {

	public WebDriver driver = PortalPlatform.getDriver();
	public WebElement element;
	public JavascriptExecutor js = (JavascriptExecutor) driver;
	public Robot r;

	public void launchUrl(String url) {
		driver.get(url);

	}

	public void implicitWait() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	/**
	 * Wait for with the element to be clickable or visible
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @param timeoutinseconds
	 *            - desired wait time
	 * @param condition
	 *            this is either visibilityOfElementLocated or ElementToBeClickable
	 * @return
	 */
	public WebElement explicitwait(WebElement webElement, int timeoutinseconds, String condition) {
		if (condition.equalsIgnoreCase("visibilityOfElementLocated")) {
			element = new WebDriverWait(driver, timeoutinseconds).until(ExpectedConditions.visibilityOf(webElement));
			return element;
		}

		if (condition.equalsIgnoreCase("ElementToBeClickable")) {
			element = new WebDriverWait(driver, timeoutinseconds)
					.until(ExpectedConditions.elementToBeClickable(webElement));
			return element;
		}
		return element;
	}

	public boolean isElementNotDisplayed(List<WebElement> element) throws Exception {
		boolean result = false;
		try {
			if (element.size() == 0)
				result = true;
		} catch (Exception e) {
			result = false;
		}
		return result;
	}

	public void maximize() {
		driver.manage().window().maximize();

	}

	/**
	 * Returns a true/false based on the element (checkboxes, radio buttons) being
	 * checked
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @return boolean
	 */
	public boolean isElementChecked(WebElement webElement) throws Exception {
		boolean result = webElement.isSelected();
		return result;
	}

	public void btnClick(WebElement element) {

		if (isElementDisplayed(element) && (isEnable(element)) && isElementClickable(element)) {
			element.click();
		}
	}

	/**
	 * Reads and provides the text found at the locator key
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @return
	 */
	public String getText(WebElement webElement) throws Exception {
		explicitwait(webElement, 30, "visibilityOfElementLocated");
		String fieldValue = element.getText();
		return fieldValue;
	}

	public void fill(WebElement element, String value) {
		if (isElementDisplayed(element) && isEnable(element)) {
			element.sendKeys(value);
		}
	}
	/*
	 * public static String dataRead(int row, int cell) throws FileNotFoundException
	 * { File f=new File(""); FileInputStream fis=new FileInputStream(f); Workbook
	 * w=new XSSFWorkbook(fis); Sheet sheet=w.getSheet(""); Row r=sh.getRow(row);
	 * Cell c=r.getCells(cell); String value=c.getStringCellValue(); return value; }
	 */

	public boolean isEnable(WebElement element) {
		return element.isEnabled();
	}

	/**
	 * Returns a true/false based on the element being displayed or not
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @return boolean
	 */

	public boolean isElementDisplayed(WebElement webElement) {
		boolean result;
		try {
			explicitwait(webElement, 60, "visibilityOfElementLocated");
			result = element.isDisplayed();
		} catch (Exception e) {
			result = false;
		}
		return result;
	}

	public boolean isElementClickable(WebElement webElement) {
		boolean result;
		try {
			explicitwait(webElement, 60, "ElementToBeClickable");
			result = element.isDisplayed();
		} catch (Exception e) {
			result = false;
		}
		return result;
	}

	/**
	 * Returns a true/false based on the element being enabled or not This can help
	 * determine whether inputs are disabled, for example
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @return boolean
	 */
	public boolean isElementEnabled(WebElement webElement) throws Exception {
		return webElement.isEnabled();
	}

	/**
	 * Returns a true/false based on the element being clickable - i.e. if it is
	 * both displayed and enabled This can help determine whether inputs are
	 * disabled, for example
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @return boolean
	 */
	/*
	 * public boolean isElementClickable(WebElement webElement) throws Exception {
	 * boolean elementIsDisplayed = isElementDisplayed(webElement); boolean
	 * elementIsEnabled = isElementEnabled(webElement); if (elementIsDisplayed &
	 * elementIsEnabled) { return true; } else { return false; } }
	 */

	/**
	 * Clicks the web element provided once it's clickable
	 *
	 * @param webElement
	 *            - WebElement of the application
	 */
	public void clickWithWait(WebElement webElement) throws Exception {
		explicitwait(webElement, 60, "ElementToBeClickable");
		webElement.click();
	}

	public List<String> dropDownGetAllOptions(WebElement element) {
		List<String> allOptions = new ArrayList<String>();
		List<WebElement> Options = new Select(element).getOptions();
		for (WebElement eachOption : Options) {
			String text = eachOption.getText();
			allOptions.add(text);
		}
		return allOptions;
	}

	public String dropDownFirstSelectedOption(WebElement element) {
		return new Select(element).getFirstSelectedOption().getText();
	}

	/**
	 * Reads and provides the value of the an attribute specified for a specific
	 * object
	 *
	 * @param webElement
	 *            - WebElement of the application
	 * @param attribute
	 *            - the name of the attribute whose text value you wish to return
	 * @return the value of that attribute
	 */
	public String getAttribute(WebElement webElement, String attribute) throws Exception {
		return webElement.getAttribute(attribute);
	}

	/**
	 * clearValue method to default to xpath if no type is provided
	 *
	 * @param webElement
	 *            - WebElement of the application
	 */
	public void clearValue(WebElement webElement) throws Exception {
		webElement.clear();
	}

	public void clickEnter() throws AWTException {
		r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
	}

	public void backSpace() throws AWTException {
		r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_A);
		r.keyRelease(KeyEvent.VK_A);
		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_DELETE);
		r.keyRelease(KeyEvent.VK_DELETE);
	}

	public int textToInt(String string) {
		String[] splitString = string.split(" ");
		int length = splitString.length;
		int y = Integer.valueOf(splitString[length - 1]);
		return y;
	}

	public List<WebElement> listOfElements(String element) {
		List<WebElement> findElements = driver.findElements(By.xpath(element));
		return findElements;
	}

	public String getUrl() {
		return driver.getCurrentUrl();
	}

	public String getTitle() {
		return driver.getTitle();
	}

	public void selectByVisibleText(WebElement element, String data) {
		if (isElementDisplayed(element)) {
			new Select(element).selectByVisibleText(data);
		}
	}

	public void selectByVisibleValue(WebElement element, String data) {
		if (isElementDisplayed(element)) {
			new Select(element).selectByValue(data);
		}
	}

	public void selectByVisibleIndex(WebElement element, int data) {
		if (isElementDisplayed(element)) {
			new Select(element).selectByIndex(data);
		}
	}

	public void type(WebElement element, String data) {

		if (isElementDisplayed(element) && isEnable(element)) {
			// System.out.println("test"+element+data);
			element.sendKeys(data);

		}
	}
		public void scrolltillElement(WebDriver driver,WebElement element) {
		JavascriptExecutor js=(JavascriptExecutor) driver;
		int y=element.getLocation().getY();
		js.executeScript("window.scrollBy(0,"+y+")",element);
		
	}

	public WebElement inputWebelement(String s) {
		WebElement element = driver.findElement(By.xpath("//button[text()='" + s + "']"));
		return element;
	}

	public String getAttributeTitle(String input) {
		String stirng = driver.findElement(By.xpath("(//span[@title='" + input + "'])[1]")).getAttribute("title");
		return stirng;
	}

	public void clickBeforeButton(WebElement element) {
		Actions build = new Actions(driver);
		build.moveToElement(element).click().perform();
	}

	public void moveToElementAndClick(WebElement element) {
		Actions act = new Actions(driver);
		act.moveToElement(element);
		act.click().perform();
	}

	public void doubleClickElement(WebElement element) {
		Actions act = new Actions(driver);
		act.doubleClick(element).build().perform();
	}

	public void scrollDown(WebElement element) {
		js.executeScript("arguments[0].scrollIntoView(true)", element);
	}

	public void scrollUp(WebElement element) {
		js.executeScript("arguments[0].scrollIntoView(false)", element);
	}

	public void checkImage(WebElement webElement) throws Exception {

		Boolean ImagePresent = (Boolean) ((JavascriptExecutor) driver).executeScript(
				"return arguments[0].complete && typeof arguments[0].naturalWidth != \"undefined\" && arguments[0].naturalWidth > 0",
				webElement);
		if (ImagePresent) {
			System.out.println("Image displayed.");
		} else {
			System.out.println("Image not displayed.");
		}
	}

	public Date conversionDate(String type, int value) {
		Date current_time = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(current_time);
		if (type.equalsIgnoreCase("hours"))
			cal.add(Calendar.HOUR, value);
		else if (type.equalsIgnoreCase("mins"))
			cal.add(Calendar.MINUTE, value);

		return cal.getTime();
	}

	public Date getcurrentDate() {
		Date current_time = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(current_time);

		return cal.getTime();
	}

	public void KeyBoard() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);

	}

	public void custom_click(WebElement element) throws InterruptedException {
		int i = 0;
		while (i < 20) {
			try {
				element.click();
				break;
			} catch (Exception e1) {
				// TODO: handle exception
				Thread.sleep(2000);
				i++;
			}
		}
	}

	public void clickUsingJavaScript(WebElement element) {
		js.executeScript("arguments[0].click();", element);
	}

	public void closeApp() {
		driver.close();
	}

	public void quitApp() {
		driver.quit();
	}

	public void keyBoardTab() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_TAB);
		r.keyRelease(KeyEvent.VK_TAB);
		
	}
	public void enterKey() throws AWTException {
		Robot r=new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
	}

	public void doubleClick(WebElement element) {
		Actions build = new Actions(driver);
		build.doubleClick(element).build().perform();
	}

	public void scroll(WebElement element) {

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].scrollIntoView();", element);

	}

	public void scrollHorizontal() throws Exception {
		r = new Robot();
		r.keyPress(KeyEvent.VK_RIGHT);
		r.keyRelease(KeyEvent.VK_RIGHT);
	}

	public void keyDelete() throws AWTException {
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_A);
		r.keyRelease(KeyEvent.VK_A);
		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_DELETE);
		r.keyRelease(KeyEvent.VK_DELETE);
	}

	public void implicitWait1(int volume, TimeUnit OutPutType) {
		driver.manage().timeouts().implicitlyWait(volume, OutPutType);

	}

	public void clearTextBox(WebElement ele) {
		String s = Keys.chord(Keys.CONTROL, "a");
		ele.sendKeys(s);
		ele.sendKeys(Keys.DELETE);
	}

	public void selectByText(WebElement element ,String text) {
		Select s=new Select(element);
		s.selectByVisibleText(text);
		
	}
	public void  moveToElement(WebDriver driver,WebElement element){

			
				Actions act = new Actions(driver);
				act.moveToElement(element).perform();;
	 }
	public void selectByIndex(WebElement element ,int index) {
		Select s=new Select(element);
        s.selectByIndex(index);		
		
	}
	public void refresh(WebDriver driver) {
		driver.navigate().refresh();
	}
	public void back(WebDriver driver) {
		driver.navigate().back();
	}
	
}
