package commonUtilities;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class ReportClass {

	public static void jvmReport(String jsonFile) {
		Configuration configuration =new Configuration(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\Reports"),"WSI-MCP Reports");
		configuration.addClassifications("Sprint", "1");
		configuration.addClassifications("Browser", "Chrome");
		configuration.addClassifications("OS", "Windows");
		
		List<String> jsonFiles=new ArrayList<String>();
		jsonFiles.add(jsonFile);
		ReportBuilder builder=new ReportBuilder(jsonFiles, configuration);
		builder.generateReports();

	}

}
