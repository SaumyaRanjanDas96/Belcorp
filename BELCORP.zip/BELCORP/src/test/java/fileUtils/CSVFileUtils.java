package fileUtils;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CSVFileUtils {
	String file;
	FileWriter fw;
	FileReader fr;
	public CSVFileUtils(String file) throws IOException {
		// TODO Auto-generated constructor stub
		this.file=file;
		fw=new FileWriter(file,true);
		fr=new FileReader(file);
}
	public void writeToCSV(String s1,long time) throws IOException
	{
		fw.write(s1);
		fw.write(",");
		fw.write(""+time);
		fw.write("\n");
	}
	public void writeToCSV(String s1,String s2) throws IOException
	{
		fw.write(s1);
		fw.write(",");
		fw.write(s2);
		fw.write("\n");
	}
	public void saveCSV() throws IOException
	{
		fw.flush();
		fw.close();
	}
	public void writeToCSV(String string, String string2, String string3) throws IOException {
		// TODO Auto-generated method stub
		fw.write(string);
		fw.write(",");
		fw.write(string2);
		fw.write(",");
		fw.write(string3);
		fw.write("\n");
		
	}
	public void writeToCSV(String string, String string2, long time) throws IOException {
		// TODO Auto-generated method stub
		fw.write(string);
		fw.write(",");
		fw.write(string2);
		fw.write(",");
		fw.write(""+time);
		fw.write("\n");
		
		
	}

}
