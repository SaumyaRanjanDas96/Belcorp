package fileUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class FileLib {
	static String filePath = "./data/testData.xlsx";
	public FileInputStream fisObj;
	public String getDataFromProperties(String key) {

		try {
			fisObj = new FileInputStream("./data/commondata.properties");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Properties pObj = new Properties();
		try {
			pObj.load(fisObj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//pObj.store(new FileOutputStream("./data/commondata.properties"), "msg");
		String value = pObj.getProperty(key);
		return value;
	}

	public void setDataFromProperties(String key, String value) throws IOException {
		FileInputStream fisObj = new FileInputStream("./data/commondata.properties");
		Properties pObj = new Properties();
		pObj.load(fisObj);
		pObj.setProperty(key, value);
		pObj.store(new FileOutputStream("./data/commondata.properties"), "msg");
		return;
	}
	/*
	 * public String getProperties(String key) throws IOException { FileInputStream
	 * fisObj = new FileInputStream("./data/commondata.properties"); Properties pObj
	 * = new Properties(); pObj.load(fisObj);
	 */

	public String getExcelData(String sheetName, int rowNum, int colNum)
			throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheetName);
		Row row = sh.getRow(rowNum);
		String data = row.getCell(colNum).getStringCellValue();
		wb.close();
		return data;
	}

	public void setExcelData(String sheetName, int rowNum, int colNum, String data) throws IOException {
		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheetName);
		Row row = sh.getRow(rowNum);
		Cell cell = row.createCell(colNum);
		cell.setCellValue(data);
		FileOutputStream fos = new FileOutputStream(filePath);
		wb.write(fos);
	}

	public int getRowCount(String sheetName) throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheetName);
		int rowIndex = sh.getLastRowNum();
		sh.getPhysicalNumberOfRows();
		return rowIndex;
	}

	public int getColCount(String sheetName) throws EncryptedDocumentException, IOException {
		FileInputStream fis = new FileInputStream(filePath);
		Workbook wb = WorkbookFactory.create(fis);
		Sheet sh = wb.getSheet(sheetName);
		int colIndex = sh.getRow(0).getPhysicalNumberOfCells();
		return colIndex;
	}

}
