package fileUtils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesFileUtils {
	Properties p;
	//String file;
public PropertiesFileUtils() throws FileNotFoundException, IOException {
	// TODO Auto-generated constructor stub
	
p=new Properties();
//p.load(new FileInputStream("file"));

}

public void setValue(String s1,String string)
{
	p.setProperty(s1,string);

}
public void saveProperties(String file) throws FileNotFoundException, IOException
{
	p.store(new FileOutputStream(file,true), null);
}
}
