package helpers;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.cucumber.listener.Reporter;

import cucumber.api.Scenario;
import platforms.PortalPlatform;

public class CommunicationHelper {

    public static String takeScreenShot(Scenario scenario) throws Exception {
        String screenShotPath = "";
        String screenshotName = scenario.getName().replaceAll(" ", "_");
        String featureName = scenario.getId().split(":")[0].replace("/", "_");
        try {
                File scrFile = ((TakesScreenshot) PortalPlatform.getDriver()).getScreenshotAs(OutputType.FILE);
                
                

                screenShotPath = "target/report/FailureScreenShots/" + screenshotName + "/" + featureName + ".png";
                FileUtils.copyFile(scrFile, new File(screenShotPath));
                final byte[] screenshot = ((TakesScreenshot) PortalPlatform.getDriver()).getScreenshotAs(OutputType.BYTES);
                scenario.embed(screenshot, "image/png");
                Reporter.addScreenCaptureFromPath("FailureScreenShots/" + screenshotName + "/" + featureName + ".png",               "Screen shot");
      
        } catch (Exception e) {
        	e.printStackTrace();
            throw new Exception("Unable to Take Screen Shot");
        }
        return screenShotPath;
    }

 

}