package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import io.cucumber.datatable.DataTable;
import junit.framework.Assert;
import platforms.PortalPlatform;

public class Belcorp_ForgotPassword  extends GenericClass{
	
	public Belcorp_ForgotPassword() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	
	@FindBy(xpath="//a[@class='cms-image-link']/child::img[@alt='Bic cyzone User icon']")
	private WebElement usericon;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-loginID-34204365708012870']")
	private WebElement email;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-password-31926558999156360']")
	private WebElement password;
	@FindBy(xpath="//input[@value='Ingresa a tu cuenta']")
	private WebElement submit;
	@FindBy(xpath="//span[.='Este campo es obligatorio']")
	private WebElement verifytextwithoutpw;
	@FindBy(xpath="//a[.='�Olvidaste tu contrase�a?']/preceding-sibling::label")
	private WebElement verifytextwithwrongpw;
	
	
	@FindBy(xpath="//a[contains(.,'�Olvidaste tu contrase�a?')]")
	private WebElement forgotpassword;
	@FindBy(xpath="//label[.='�Olvidaste tu contrase�a?']")
	private WebElement forgotpwtext;
	
	
	public WebElement getUsericon() {
		return usericon;
	}
	public WebElement getEmail() {
		return email;
	}
	public WebElement getPassword() {
		return password;
	}
	public WebElement getSubmit() {
		return submit;
	}
	public WebElement getverifytextwithoutpw() {
		return verifytextwithoutpw;
	}
	public WebElement getverifytextwithwrongpw() {
		return verifytextwithwrongpw;
		
	}
	public WebElement getForgotpassword() {
		return forgotpassword;
	}
	public WebElement getForgotpwtext() {
		return forgotpwtext;
	}
	public void clickUser() {
		btnClick(getUsericon());
		
	}
	
	public void loginWthWrongPassword(DataTable data) {
		List<List<String>> list = data.asLists();
		type(getEmail(), list.get(1).get(0));
        type(getPassword(), list.get(1).get(1));
        btnClick(getSubmit());
        refresh(driver); 
        
       	
	}
	public void verifyTextWithWrongPW() {
		String actual = verifytextwithwrongpw.getText();
		String expected="La direcci�n de correo o la contrase�a es incorrecta.";
		Assert.assertEquals(expected, actual);
		
	}
	public void loginWithoutPassword(DataTable data1 ) {
		List<List<String>> list1 = data1.asLists();
		type(getEmail(), list1.get(1).get(0));
		btnClick(getSubmit());
		refresh(driver);

		
	}
	
	public void verifytextWithoutPW() {
		String actual1=verifytextwithoutpw.getText();
		String expected1= "Este campo es obligatorio";
		Assert.assertEquals(expected1, actual1);
	}
	public void clickForgotPassword() {
		
		btnClick(getForgotpassword());
	}
	public void verifyForgotPwText() {
		String actual2 = forgotpwtext.getText();
		String expected2="�Olvidaste tu contrase�a?";
		Assert.assertEquals(expected2, actual2);
	}

}
