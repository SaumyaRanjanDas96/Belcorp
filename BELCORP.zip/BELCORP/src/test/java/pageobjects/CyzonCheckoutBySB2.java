package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import io.cucumber.datatable.DataTable;
import platforms.PortalPlatform;

public class CyzonCheckoutBySB2 extends GenericClass {
	
	public CyzonCheckoutBySB2() {
    PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	@FindBy(xpath="//img[@alt='Bic cyzone User icon']/preceding::a[@class='cms-image-link']")
	private WebElement usericon;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-loginID-34204365708012870']")
	private WebElement email;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-password-31926558999156360']")
	private WebElement password;
	@FindBy(xpath="//input[@value='Ingresa a tu cuenta']")
	private WebElement submit;
	
	@FindBy(xpath="//a[.='labial en barra hidratante hydrafull']")
	private WebElement product;
	
	@FindBy(xpath="//span[@class='input-group-btn']/child::button[.='+']")
	private WebElement qtyselector;
	
	@FindBy(xpath="//button[contains(.,'Agregar a la bolsa')]")
	private WebElement addtocart;
	

	@FindBy(xpath="//div[@class='mini-cart-icon']/preceding::a[@class='mini-cart-link js-mini-cart-link']")
	private WebElement cartsymbol;
	
	@FindBy(xpath="(//button[contains(.,'Ir a pagar')])[2]")
    private WebElement buynow;

	public WebElement getUsericon() {
		return usericon;
	}


	public WebElement getEmail() {
		return email;
	}


	public WebElement getPassword() {
		return password;
	}


	public WebElement getSubmit() {
		return submit;
	}


	public WebElement getProduct() {
		return product;
	}


	public WebElement getQtyselector() {
		return qtyselector;
	}


	public WebElement getAddtocart() {
		return addtocart;
	}


	public WebElement getCartsymbol() {
		return cartsymbol;
	}
	public WebElement getBuynow() {
		return buynow;
	}
   
	public void clickUserIcon() {
		btnClick(getUsericon());
	}
	public void login(DataTable data) {
		List<List<String>> list = data.asLists();
		type(getEmail(), list.get(1).get(0));
		type(getPassword(), list.get(1).get(1));
		btnClick(getSubmit());
	}
	public void clickOnProduct() {
		scroll(getProduct());
		btnClick(getProduct());
		
	}
	public void verifyQtySelector() {
		if(getQtyselector().isEnabled()) {
			System.out.println("button is working");
		}
	}
	public void clickAddToCart() {
		btnClick(getAddtocart());
		moveToElementAndClick(getCartsymbol());
		btnClick(getCartsymbol());
		
	}
	public void verifyCartbutton() {
		if(getCartsymbol().isEnabled()) {
			System.out.println("cart button is working");
		}
	}
	public void buyProduct() {
		btnClick(getBuynow());
	}
}
