package pageobjects;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import io.cucumber.datatable.DataTable;
import platforms.PortalPlatform;

public class CyzonPom extends GenericClass{
	
	public CyzonPom() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	

	@FindBy(xpath="//a[contains(.,'moda y accesorios')]")
	private WebElement fashion;
	@FindBy(xpath="//div[@class='yCmsComponent sub-navigation-section second-level']/child::a[contains(.,'Hombre')]")
	private WebElement men;
	@FindBy(xpath="//button[@id='cboxClose']")
	private WebElement closebtn;
	@FindBy(xpath="//div[contains(.,'Filtrar por Precio')]/child::span[@class='glyphicon facet__arrow']")
	private WebElement scrollelement;
	@FindBy(xpath="//span[@class='facet__list__text']/parent::span/child::span[contains(.,'7')]/following-sibling::span")
	private WebElement sortbyprice;
	@FindBy(xpath="//a[contains(.,'mochila de hombre jack')]")
	private WebElement bag;
	
	@FindBy(xpath="//button[contains(.,'Agregar a la bolsa')]")
	private WebElement addtobag;
	@FindBy(xpath="//a[@class='btn btn-black btn-block add-to-cart-button']")
	private WebElement buy;
	@FindBy(xpath="//button[@id='checkout-display-continueCheckout']")
	private WebElement checkout;
	
	
	@FindBy(name="firstName")
	private WebElement firstname;
	@FindBy(name="lastName")
	private WebElement lastname;
	@FindBy(name="email")
	private WebElement email;
	@FindBy(id="guest.confirm.email")
	private WebElement confirmemail;
	
	@FindBy(name="agreeToReceivePublicity")
	private WebElement checkbox;
	@FindBy(xpath="//button[.='Inicia como Invitado']")
	private WebElement guest;
    
	
	@FindBy(xpath="//select[@name='regionIsoParent2']")
	private WebElement department;
	@FindBy(xpath="//select[@name='regionIsoParent1']")
	private WebElement province;
	@FindBy(xpath="//select[@name='regionIso']")
	private WebElement district;
	@FindBy(xpath="//input[@id='address.line1']")
	private WebElement address;
	@FindBy(xpath="//input[@name='phone']")
	private WebElement mob;
	
	@FindBy(xpath="//button[.='CLICK AQU� PARA CONTINUAR']")
	private WebElement continuebtn;
	
	@FindBy(xpath="//div[.='Opci�n de Env�o']")
	private WebElement text;
	

	public WebElement getFashion() {
		return fashion;
	}
	public WebElement getMen() {
		return men;
	}

	public WebElement getClosebtn() {
		return closebtn;
	}
	public WebElement getScrollelement() {
		return scrollelement;
	}

	public WebElement getSortbyprice() {
		return sortbyprice;
	}

	public WebElement getBag() {
		return bag;
	}

	public WebElement getAddtobag() {
		return addtobag;
	}

	public WebElement getBuy() {
		return buy;
	}
	public WebElement getCheckout() {
		return checkout;
	}
	public WebElement getFirstname() {
		return firstname;
	}

	public WebElement getLastname() {
		return lastname;
	}

	public WebElement getEmail() {
		return email;
	}


	public WebElement getConfirmemail() {
		return confirmemail;
	}

	public WebElement getCheckbox() {
		return checkbox;
	}

	public WebElement getGuest() {
		return guest;
	}

	public WebElement getDepartment() {
		return department;
	}


	public WebElement getProvince() {
		return province;
	}


	public WebElement getDistrict() {
		return district;
	}


	public WebElement getAddress() {
		return address;
	}
	public WebElement getMob() {
		return mob;
	}
	public WebElement getContinuebtn() {
		return continuebtn;
	}
	public WebElement getText() {
		return text;
	}
    
	public void clickMenFashion() {
		moveToElement(driver, fashion);
		btnClick(men);	
		scroll(scrollelement);
	}
	public void clickBag() {
		btnClick(sortbyprice);
		btnClick(bag);
	}
	public void checkOut() {
		
		btnClick(addtobag);
		btnClick(buy);
		btnClick(checkout);
	}
	public void enterDetails(DataTable dataTable) {
		List<List<String>> list = dataTable.asLists();
		firstname.sendKeys(list.get(1).get(0));
		lastname.sendKeys(list.get(1).get(1));
		email.sendKeys(list.get(1).get(2));
		confirmemail.sendKeys(list.get(1).get(3));
		
		checkbox.click();
		guest.click();
		
	}
	public void enterDetailsAdress(DataTable dataTable1) {
	
		btnClick(department);
		selectByText(department, "AMAZONAS");
		
		btnClick(province);
		selectByText(province, "BONGARA");
		
		btnClick(district);
		selectByIndex(district, 1);
		
    List<List<String>> list1 = dataTable1.asLists();
    address.sendKeys(list1.get(1).get(0));
    mob.sendKeys(list1.get(1).get(1));
    
	   btnClick(continuebtn);			
		
	}
	public void validText() {
		String actual=text.getText();
		String expected = "OPCI�N DE ENV�O";
		Assert.assertEquals(expected, actual);

	}
	
	}
	


