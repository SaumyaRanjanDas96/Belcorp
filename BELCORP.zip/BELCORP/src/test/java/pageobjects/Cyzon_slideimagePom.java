package pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import io.cucumber.datatable.DataTable;
import junit.framework.Assert;
import platforms.PortalPlatform;

public class Cyzon_slideimagePom extends GenericClass {
	
	public Cyzon_slideimagePom() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	@FindBy(xpath="//li[@data-slide-to='0']")
	private WebElement slidebar;
	@FindBy(xpath="(//a[@class='cms-image-link'])[1]")
	private WebElement usericon;
	
	@FindBy(xpath="//input[@placeholder='Ingresa tu nombre *']")
	private WebElement name;
	@FindBy(xpath="//input[@placeholder='Ingresa tu apellido *']")
	private WebElement lastname;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-textbox-116360874187414000']")
	private WebElement email;
	@FindBy(xpath="//input[@placeholder='Confirma tu correo electr�nico *']")
	private WebElement cnfemail;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-password-31296778985258210']")
	private WebElement password;
	@FindBy(xpath="//input[@placeholder='Confirma tu contrase�a *']")
	private WebElement cnfpassword;
	@FindBy(xpath="//input[@id='gigya-checkbox-68066337947468360']")
	private WebElement fstcheckbox;
	@FindBy(xpath="//input[@id='gigya-checkbox-117286101330919040']")
	private WebElement scndcheckbox;
	@FindBy(xpath="//input[@id='gigya-checkbox-132284802991910320']")
	private WebElement thrdcheckbox;
	@FindBy(xpath="//input[@value='Crear cuenta']")
	private WebElement submit;
	
	@FindBy(xpath="//li[contains(.,'Hola soumya ')]")
	private WebElement verifytext;

	public WebElement getSlidebar() {
		return slidebar;
	}
	public WebElement getUsericon() {
		return usericon;
	}

	public WebElement getName() {
		return name;
	}

	public WebElement getLastname() {
		return lastname;
	}

	public WebElement getEmail() {
		return email;
	}

	public WebElement getCnfemail() {
		return cnfemail;
	}

		public WebElement getPassword() {
		return password;
	}

		public WebElement getCnfpassword() {
		return cnfpassword;
	}

	public WebElement getFstcheckbox() {
		return fstcheckbox;
	}

	public WebElement getScndcheckbox() {
		return scndcheckbox;
	}

	public WebElement getThrdcheckbox() {
		return thrdcheckbox;
	}

	public WebElement getSubmit() {
		return submit;
	}

	public WebElement getVerifytext() {
    return verifytext;
	}

   public void clickSlidebar() {
	   btnClick(getSlidebar());
   }
   public void clickUser() {
	  btnClick(getUsericon());
   }
   public void enterDetails(DataTable datatable) {
	  List<List<String>> list = datatable.asLists();
	  type(getName(), list.get(1).get(0));
	  type(getLastname(), list.get(1).get(1));
	  type(getEmail(), list.get(1).get(2));
	  type(getCnfemail(), list.get(1).get(3));
	  type(getPassword(), list.get(1).get(4));
	  type(getCnfpassword(), list.get(1).get(5));
	  
	  
	   btnClick(getFstcheckbox());
	   btnClick(getScndcheckbox());
	   btnClick(getThrdcheckbox());
	   btnClick(getSubmit());
   }
   public void verifyText() {
	   String actual = verifytext.getText();
	   String expected="Hola soumya ranjan";
	   Assert.assertEquals(expected, actual);
	   
   }
}
