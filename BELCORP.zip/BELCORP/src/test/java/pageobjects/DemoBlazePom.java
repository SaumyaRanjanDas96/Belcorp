package pageobjects;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import platforms.PortalPlatform;

public class DemoBlazePom extends GenericClass {
	public DemoBlazePom() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	//samsung
	@FindBy(xpath="//a[.='Samsung galaxy s6']")
	private WebElement samsunggalaxy;
	@FindBy(xpath="//a[.='Add to cart']")
	private WebElement addtocart;
	@FindBy(xpath="//a[.='Cart']")
	private WebElement cart;
	@FindBy(xpath="//button[.='Place Order']")
	private WebElement button;
	
	
	@FindBy(id="name")
	private WebElement name1;
	@FindBy(id="country")
	private WebElement country1;
	@FindBy(id="city")
    private WebElement city1;
	@FindBy(id="card")
	private WebElement creditcard1;
	@FindBy(id="month")
	private WebElement month1;
	@FindBy(id="year")
	private WebElement year1;
	@FindBy(xpath="//button[.='Purchase']")
	private WebElement purchase;
	
	
	public void setclickSamsung() {
		samsunggalaxy.click();
		
	}
	public void setclickAddToCart() {
		addtocart.click();
		
	}
	public void setClickcart() {
		cart.click();
		button.click();
	}
	public void setEnterDetails(String name,String country,String city,String creditcard,String month,String year) {
		name1.sendKeys(name);
		country1.sendKeys(country);
		city1.sendKeys(city);
		creditcard1.sendKeys(creditcard);
		month1.sendKeys(month);
		year1.sendKeys(year);
	    purchase.click();
	    //
	}
	
	public void setVerifyOrder() {
		String message = driver.switchTo().alert().getText();
		Assert.assertEquals("Thank you for your purchase!", message);
	}
	//nokia
	
	
	@FindBy(xpath="//a[.='Nokia lumia 1520']")
	private WebElement nokia;
	
	
	public void setClickNokia() {
		nokia.click();
	}
	
	//nexus
	@FindBy(xpath="//a[.='Nexus 6']")
    private WebElement nexus;	

	

	public void setClickNexus() {
		nexus.click();
	}
}

