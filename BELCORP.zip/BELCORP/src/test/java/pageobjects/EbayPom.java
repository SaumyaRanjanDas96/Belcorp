package pageobjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import commonUtilities.GenericClass;
import platforms.PortalPlatform;

public class EbayPom extends GenericClass {
	
	public EbayPom() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	@FindBy(id="gh-ac")
	private WebElement searchbox;
	@FindBy(xpath="//h3[.='Apple iPhone 8 Plus 64GB Factory Unlocked AT&T Verizon T-Mobile Unlocked']")
	private WebElement apple;
	@FindBy(id="binBtn_btn")
	private WebElement buynow;
	
	
	public void setSearchMobile(String m) {
		
		
		searchbox.sendKeys(m+Keys.ENTER);
		
	}
	public void setclickOnMobile() {
		apple.click();
	}
	public void setverifyBuynow() {
		if(buynow.isEnabled()) {
			System.out.println("enabled");
		}
	}
		
	

}
