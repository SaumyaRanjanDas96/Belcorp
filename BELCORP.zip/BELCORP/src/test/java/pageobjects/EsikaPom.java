package pageobjects;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import io.cucumber.datatable.DataTable;
import platforms.PortalPlatform;

public class EsikaPom extends GenericClass {
	
	
	public EsikaPom() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	@FindBy(xpath="(//a[@id='lnk-sup-esika'])[2]")
	private WebElement esika;
	
	@FindBy(xpath="//a[.='Ligne Experte Acondicionador Reconstruit']")
	private WebElement shampoo;
	@FindBy(xpath="//button[@id='addToCartButton']")
	private WebElement addtobag;
	@FindBy(xpath="//a[@class='btn btn-black btn-block add-to-cart-button']")
	private WebElement buy;
	@FindBy(xpath="//button[@id='checkout-display-continueCheckout']")
	private WebElement checkout;
	
	
	@FindBy(name="firstName")
	private WebElement firstname;
	@FindBy(name="lastName")
	private WebElement lastname;
	@FindBy(name="email")
	private WebElement email;
	@FindBy(id="guest.confirm.email")
	private WebElement confirmemail;
	
	@FindBy(name="agreeToReceivePublicity")
	private WebElement checkbox;
	@FindBy(xpath="//button[.='Inicia como Invitado']")
	private WebElement guest;
	
	
	public void setclickEsika() {
		
		esika.click();
	}
	
	public void setClickShampoo() {
		shampoo.click();
	}
	
	public void setClickAddToCart() {
		addtobag.click();
		buy.click();
		checkout.click();
	}
	public void setEnterDetails(DataTable dataTable) {
		List<List<String>> list = dataTable.asLists();
		firstname.sendKeys(list.get(1).get(0));
		lastname.sendKeys(list.get(1).get(1));
		email.sendKeys(list.get(1).get(2));
		confirmemail.sendKeys(list.get(1).get(3));
		
		checkbox.click();
		guest.click();
		
	}
	public void setVerifyOrder() {
		WebElement elements = driver.findElement(By.xpath("//div[.='Direcci�n de Env�o']"));
		String text= elements.getText();
		
		Assert.assertEquals("DIRECCI�N DE ENV�O", text);
	}
	

}
