package pageobjects;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import commonUtilities.GenericClass;

public class FlipkartPom extends GenericClass{
	
	public FlipkartPom() {
		PageFactory.initElements(driver, this);
	}
	
	//@FindBy(xpath="//a[.='Login']")
	//private WebElement loginlink;
	@FindBy(xpath="//button[@class='_2KpZ6l _2doB4z']")
	private WebElement closebtn;
	@FindBy(xpath="//span[.='Enter Email/Mobile number']/../../input")
	private WebElement username;
	
	@FindBy(xpath="//span[.='Enter Password']/../../input")
	private WebElement password;
	
	@FindBy(xpath="//span[contains(.,'Login')]/../../button")
	private WebElement loginbtn;
	
	@FindBy(name="q")
	private WebElement searchbar;
	@FindBy(xpath="//div[.='SAMSUNG Galaxy F41 (Fusion Blue, 128 GB)']")
	private WebElement samsungmob;
	@FindBy(xpath="//button[@class='_2KpZ6l _2U9uOA ihZ75k _3AWRsL']/../..")
	private WebElement buynow;
	@FindBy(xpath="//div[.='APPLE iPhone 12 (Blue, 128 GB)']")
	private WebElement applemobile;
	
	
	public void setLogin(String un,String pw) {
		username.sendKeys(un);
		password.sendKeys(pw);
		
		
	}
	public void setClose() {
		closebtn.click();
	}
	
	public void setsearchSamsung(String s) {
		searchbar.sendKeys(s+Keys.ENTER);
		
	}
	public void setclickSamsung() {
		samsungmob.click();
		Set<String> alltabs = driver.getWindowHandles();
		Iterator<String> it=alltabs.iterator();
		String ptab = it.next();
		String ctab=it.next();
        driver.switchTo().window(ptab);
        driver.switchTo().window(ctab);
		
	}
	public void setsearchApple(String a) {
		searchbar.sendKeys(a+Keys.ENTER);
	}
	public void setclickApple() {	
		applemobile.click();
	}
	
		public void setbuyNow() {

			buynow.click();
   }
   
}
