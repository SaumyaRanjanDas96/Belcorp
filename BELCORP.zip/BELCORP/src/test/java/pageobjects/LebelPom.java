package pageobjects;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import platforms.PortalPlatform;

public class LebelPom extends GenericClass {
	
	public LebelPom() {
		
		PageFactory.initElements(PortalPlatform.getDriver(), this);
		
	}
	
	
	@FindBy(xpath="(//a[@id='lnk-sup-lbel'])[2]")
	private WebElement lebel;
	@FindBy(xpath="(//h3[@class='belcorp-cms-carousel-item__title js-belcorp-cms-carousel-item-link-trigger'])[3]")
	private WebElement fragrance;
	@FindBy(xpath="//button[@id='cboxClose']")
	private WebElement closebtn;
	@FindBy(xpath="//a[contains(.,'Bleu Intense Perfume')]")
	private WebElement blueperfume;
	
	@FindBy(xpath="//h3[.='Calificaciones']")
	private WebElement scrollelement;
	
	@FindBy(xpath="//div[@id='netreviews_reviews_section']//div[@class='left_review_part']//p")
	private List<WebElement>  user;
	
	@FindBy(xpath="//div[@id='netreviews_reviews_section']//div[@class='right_review_part']//p[@class='netreviews_customer_review']")
	private List<WebElement> comments;

	public void setClickLebel() {
		btnClick(lebel);
	}
	public void setClickfragrance() {
		
		
		
		btnClick(fragrance);
		btnClick(closebtn);
		
		
	}
	public void setClickBluePerfume() throws AWTException {
		btnClick(blueperfume);
		enterKey();
		scrolltillElement(driver, scrollelement);
		
	}
	public void setPrintUserandComments() {
		
     int count=user.size();
     
     String text=null,text1=null;
     for (int i = 0; i <count; i++) {
    	 text=user.get(i).getText();
    	 System.out.println(text);
    	 text1=comments.get(i).getText();
    	 System.out.println(text1);
		
	}
     
     System.out.print(text+":"+text1);
		
		
	}
}
