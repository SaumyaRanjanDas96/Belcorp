package pageobjects;

import static org.junit.Assert.assertNotEquals;

import java.util.List;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import commonUtilities.GenericClass;
import io.cucumber.datatable.DataTable;
import junit.framework.Assert;
import platforms.PortalPlatform;

public class PurchaseAsGoogleUser extends GenericClass {
	
	public PurchaseAsGoogleUser() {
		PageFactory.initElements(PortalPlatform.getDriver(), this);
	}
	
	
//cyzon
	
	@FindBy(xpath="//a[@class='cms-image-link']/child::img[@alt='Bic cyzone User icon']")
	private WebElement usericon;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-loginID-34204365708012870']")
	private WebElement email;
	@FindBy(xpath="//label[@class='gigya-label']/following-sibling::input[@id='gigya-password-31926558999156360']")
	private WebElement password;
	@FindBy(xpath="//input[@value='Ingresa a tu cuenta']")
	private WebElement submit;
	
	@FindBy(xpath="//a[contains(.,'moda y accesorios')]")
	private WebElement fashionandaccessories;
	@FindBy(xpath="//a[.='Bolsos y carteras']")
	private WebElement bagandpurses;
	
	@FindBy(xpath="//div[@class='price-panel']")
	private List<WebElement> pricetag;
	@FindBy(xpath="//p[@id='precioTachado_210087706']/ancestor::div[@class='price-panel']")
	private WebElement bagprice;
	
	@FindBy(xpath="//a[@id='product_productName_210087706']")
	private WebElement bag;
	@FindBy(xpath="//button[contains(.,'Agregar a la bolsa')]")
	private WebElement addtocart;
	
	@FindBy(xpath="//div[@class='mini-cart-icon']/preceding::a[@class='mini-cart-link js-mini-cart-link']")
	private WebElement cartsymbol;
	
	@FindBy(xpath="//div[@class='col-xs-6 cart-totals-right text-right grand-total']")
	private WebElement totalprice;
	
	
	
    public WebElement getUsericon() {
		return usericon;
	}
	public WebElement getEmail() {
		return email;
	}
    public WebElement getPassword() {
		return password;
    }

	public WebElement getSubmit() {
		return submit;
	}
	public WebElement getFashionandaccessories() {
		return fashionandaccessories;
	}
	public WebElement getBagandpurses() {
		return bagandpurses;
	}
	public List<WebElement> getPricetag() {
		return pricetag;
	}
	public WebElement getBagprice() {
		return bagprice;
	}
	public WebElement getBag() {
		return bag;
	}
	public WebElement getAddtocart() {
		return addtocart;
	}
	public WebElement getCartsymbol() {
		return cartsymbol;
	}
	public WebElement getTotalprice() {
		return totalprice;
	}


    public void login(DataTable data) {
    	btnClick(getUsericon());
    	List<List<String>> list = data.asLists();
    	type(getEmail(),list.get(1).get(0));
    	type(getPassword(), list.get(1).get(1));
    	btnClick(getSubmit());
    	
    	
    }
    public void clickProduct() {
    	moveToElementAndClick(getFashionandaccessories());
    	btnClick(getBagandpurses());
    }
    public void veifyCatalogAndOfferPrice() {
    	String expectedtext=getBagprice().getText();
    	int count = getPricetag().size();
    	
    	String text=null;
    	for(int i=0;i<count;i++) {
    	text = getPricetag().get(i).getText();
    		
    	}
    	Assert.assertTrue(text.contains(expectedtext));
    }
    public void clickAddtoCart() {
    	scroll(getBag());
    	btnClick(getBag());
    	btnClick(getAddtocart());
    	moveToElementAndClick(getAddtocart());
    	btnClick(getCartsymbol());
    	btnClick(getCartsymbol());
    	
    }
    
    
//	public void verifyPrice() {  
//	}
	
	//Lebel
	
	@FindBy(xpath="//div[@class='yCmsComponent yComponentWrapper']/following::a[@id='lnk-sup-lbel']")
	private WebElement lebel;
	@FindBy(xpath="//input[@placeholder='Estoy buscando...']/ancestor::div[@class='col-md-4']")
	private WebElement searchbar;
	@FindBy(xpath="//span[contains(.,'Minifragancia Satin Rouge')]")
	private List<WebElement> autosuggestion;
	@FindBy(xpath="//a[contains(.,'Minifragancia Satin Rouge')]")
	private WebElement fragrance;
	//@FindBy(xpath="//button[contains(.,'Agregar a la bolsa')]")
	//private WebElement addtocart1;
	@FindBy(xpath="//div[@class='mini-cart-icon']/preceding::a[@class='mini-cart-link js-mini-cart-link']")
	private WebElement cartsymbol1;
	
	//@FindBy(xpath="//span[@class='old-price']/ancestor::div[@class='priceContainer']")
	//private WebElement pricetag1;
	
	
	
	
	
	
}
