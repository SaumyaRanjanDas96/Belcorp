package platforms;

 


import java.io.IOException;
import java.util.concurrent.TimeUnit;

 

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

 

import fileUtils.FileLib;
import io.github.bonigarcia.wdm.WebDriverManager;

 

public class PortalPlatform  implements PortalPlatformInterface {

 

    public WebDriver driver;
    public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
    public WebElement element;
    public FileLib flib=new FileLib();
    

 

    //public static String browser="chrome_uat";
    public String getBrowserName()
    {
    String browser= flib.getDataFromProperties("browser"); 
    return browser;
    }
    //public static String url="https://supchainplanmerch-mcp-user-interface-photonqa.services.west.nonprod.wsgc.com/login";
    //public static String url="https://supchainplanmerch-mcp-user-interface-mcpuat.services.west.nonprod.wsgc.com/login";
    //public static String url= "https://mcpqa.wsgc.com";
    //https://supchainplanmerch-mcp-user-interface-mcpuat.services.west.nonprod.wsgc.com/login
    public String getUrl() 
    {
    String url=flib.getDataFromProperties("url");
    return url;
    }
    public PortalPlatform(){
        
        switch(getBrowserName()) {
        case "chrome":
            /*System.setProperty("webdriver.chrome.driver",
                    System.getProperty("user.dir") + "\\driver\\ChromeDriver\\chromedriver.exe");
        */    
            /*if(flib.getDataFromProperties("url").equals("https://supchainplanmerch-mcp-user-interface-mcpuat.services.west.nonprod.wsgc.com/login"))
            {
                WebDriverManager.chromedriver().setup();
                tlDriver.set(new ChromeDriver());
                break;
            }
            else*/
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--ignore-ssl-errors=yes");
            options.addArguments("--ignore-certificate-errors");
           // options.addArguments("--headless");
            tlDriver.set(new ChromeDriver(options));
            break;
            /*ChromeOptions options = new ChromeOptions();
            options.addArguments("--headless");
            driver = new ChromeDriver(options);*/
            

 

            //driver = new ChromeDriver();
        
        /*case "chrome_uat":
            
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--ignore-ssl-errors=yes");
            options.addArguments("--ignore-certificate-errors");
            
            ChromeOptions handlingSSL = new ChromeOptions();
            handlingSSL.setAcceptInsecureCerts(true);
            //System.setProperty("webdriver.chrome.driver",
                    //System.getProperty("user.dir") + "\\driver\\ChromeDriver\\chromedriver.exe");
            //driver = new ChromeDriver(handlingSSL);
            WebDriverManager.chromedriver().setup();
            tlDriver.set(new ChromeDriver(handlingSSL));
            break;*/
            
        case "firefox":
            WebDriverManager.firefoxdriver().setup();
             /*FirefoxOptions firefoxOptions = new FirefoxOptions();
             firefoxOptions.setAcceptInsecureCerts(false);
            tlDriver.set(new FirefoxDriver(firefoxOptions));*/
            tlDriver.set(new FirefoxDriver());
            
            break;
            
        case "edge":
            WebDriverManager.edgedriver().setup();
            /*DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
             EdgeOptions edgeOptions = new EdgeOptions();
             edgeOptions.setAcceptInsecureCerts(true);
            tlDriver.set(new EdgeDriver(capabilities));*/
            tlDriver.set(new EdgeDriver());
            break;
            
        case "ie": 
            WebDriverManager.iedriver().setup();
            tlDriver.set(new InternetExplorerDriver());
            break;
            
        case "safari":            
        
            
        }
        
    }

 

    @Override
    public void launch() throws Exception {
        tlDriver.get().get(getUrl());
        
        maximize();
        /*if(getBrowserName().equals("ie") || getBrowserName().equals("edge"))
        {
            tlDriver.get().navigate().to("javascript:document.getElementById('overridelink').click()");
        }*/
        //driver.get("javascript:document.getElementById('overridelink').click();");
        //driver.get(url);
        
    }
    
    public void maximize() {
        tlDriver.get().manage().window().maximize();
        tlDriver.get().manage().deleteAllCookies();
        tlDriver.get().manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
        //driver.manage().window().maximize();

 

    }
    
    /*public static WebDriver getDriver() {
        // TODO Auto-generated method stub
   return driver;
    }*/
    
    public static synchronized WebDriver getDriver() {
        return tlDriver.get();
    }

 

}