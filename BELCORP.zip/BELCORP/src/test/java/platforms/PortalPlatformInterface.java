package platforms;

public interface PortalPlatformInterface {


	void launch() throws Exception;
    
}