package stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.Belcorp_ForgotPassword;
import platforms.PortalPlatform;

public class BelcorpSteps_Forgotpassword {
	
	PortalPlatform p=new PortalPlatform();
	Belcorp_ForgotPassword b=new Belcorp_ForgotPassword();
	
	
	
	@Given("user must click on usericon")
	public void user_must_click_on_usericon() throws Exception {
	p.launch();    
	b.clickUser();
	}

	@When("user must login using wrong credentials")
	public void user_must_login_using_wrong_credentials(io.cucumber.datatable.DataTable data) {
		
	b.loginWthWrongPassword(data);
	
	//
	
	}

	@When("user must login using only mail id")
	public void user_must_login_using_only_mail_id(io.cucumber.datatable.DataTable data1) {
	   
	b.loginWithoutPassword(data1);
	
	//

	}

	@When("user must click on forgot password button")
	public void user_must_click_on_forgot_password_button() {
	   
	b.clickForgotPassword();
	}

	@Then("verify the text")
	public void verify_the_text() {
	   
	// b.verifyTextWithWrongPW();
	// b.verifytextWithoutPW();
	   b.verifyForgotPwText();
	}



}
