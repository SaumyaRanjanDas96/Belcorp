package stepDefinitions;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.CyzonCheckoutBySB2;
import platforms.PortalPlatform;

public class CyzonCheckOutBySB2Steps extends GenericClass {
	
	PortalPlatform p=new PortalPlatform();
	CyzonCheckoutBySB2 c=new CyzonCheckoutBySB2();
	
	

@Given("user must access cyzon url")
public void user_must_access_cyzon_url() throws Exception {
   p.launch();   
}

@When("user must click on the usericon")
public void user_must_click_on_the_usericon() {
  c.clickUserIcon();
}

@When("user must login to the application")
public void user_must_login_to_the_application(io.cucumber.datatable.DataTable data) {
  c.login(data);    
}

@When("user must click one product")
public void user_must_click_one_product() {
   c.clickOnProduct();   
}

@Then("user must validate qty selector button is enabled")
public void user_must_validate_qty_selector_button_is_enabled() {
    c.verifyQtySelector();
}

@When("add the product to cart")
public void add_the_product_to_cart() {
   c.clickAddToCart();   
}

@Then("verify cart button is enabled")
public void verify_cart_button_is_enabled() {
   c.verifyCartbutton();    
}

@When("continue buy product")
public void continue_buy_product() {
    c.buyProduct();
    }



}
