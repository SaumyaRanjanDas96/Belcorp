package stepDefinitions;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebElement;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.CyzonPom;
import platforms.PortalPlatform;

public class CyzonSteps {
	PortalPlatform p=new PortalPlatform();
	GenericClass g=new GenericClass();
	CyzonPom c=new CyzonPom();
	
		
	
	@Given("user must go to belecorp site")
	public void user_must_go_to_belecorp_site() throws Exception {
	    p.launch();
	}

	@When("user must click on men's section under fashion")
	public void user_must_click_on_men_s_section_under_fashion() {
	c.clickMenFashion();    
	}

	@When("user must select the product")
	public void user_must_select_the_product() {
	   c.clickBag();
	   
	}

	@When("user must checkout by entering details")
	public void user_must_checkout_by_entering_details(io.cucumber.datatable.DataTable dataTable) {
		c.checkOut();
		c.enterDetails(dataTable);
	    
	}

	@When("user must select the dropdown and enter the details")
	public void user_must_select_the_dropdown_and_enter_the_details(io.cucumber.datatable.DataTable dataTable1) {
	    c.enterDetailsAdress(dataTable1);
	
	}

	@Then("verify the product name")
	public void verify_the_product_name() {
	
	}



}
