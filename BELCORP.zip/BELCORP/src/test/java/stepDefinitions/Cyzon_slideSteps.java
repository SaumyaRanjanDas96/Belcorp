package stepDefinitions;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.Cyzon_slideimagePom;
import platforms.PortalPlatform;

public class Cyzon_slideSteps extends GenericClass {
	PortalPlatform p=new PortalPlatform();
	Cyzon_slideimagePom c=new Cyzon_slideimagePom();
	
	
	@Given("user must go to cyzon site")
	public void user_must_go_to_cyzon_site() throws Exception {
	    p.launch();
	}

	@When("user must click on user icon")
	public void user_must_click_on_user_icon() {
	    c.clickSlidebar();
	    c.clickUser();
	}

	@When("enter name ,lastname,email and password")
	public void enter_name_lastname_email_and_password(io.cucumber.datatable.DataTable dataTable) {
	   c.enterDetails(dataTable);
}

	@Then("verify usernametext")
	public void verify_usernametext() {
	    c.verifyText();
	}



}
