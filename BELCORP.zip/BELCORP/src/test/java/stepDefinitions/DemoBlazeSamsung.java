package stepDefinitions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.DemoBlazePom;
import platforms.PortalPlatform;

public class DemoBlazeSamsung extends GenericClass {
	DemoBlazePom d=new DemoBlazePom();
	
	PortalPlatform p=new PortalPlatform();
	
	@Given("user must visit demoblaze")
	public void user_must_visit_demoblaze() throws Exception {
	   
	p.launch();
	}

	@When("user must click on samsung mobile")
	public void user_must_click_on_samsung_mobile() {
     
		d.setclickSamsung();
	}

	@When("user must click on add to cart")
	public void user_must_click_on_add_to_cart() {
	    
		d.setclickAddToCart();
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.alertIsPresent());
		driver.switchTo().alert().accept();
        
		d.setClickcart();
		
	}

	@When("place order using {string} and {string} and {string} and {string} and {string} and {string}")
	public void place_order_using_and_and_and_and_and(String name, String country, String city, String creditcard, String month, String year) {
	   
		d.setEnterDetails(name, country,city, creditcard, month, year);
		
	}

	@Then("user must verify the order details")
	public void user_must_verify_the_order_details() {
	    d.setVerifyOrder();
	}




}
