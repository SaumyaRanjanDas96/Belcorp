package stepDefinitions;

import java.util.List;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.EbayPom;
import platforms.PortalPlatform;

public class EbaySteps extends GenericClass{
	
	EbayPom e=new EbayPom();
	PortalPlatform p=new PortalPlatform();
	
	@Given("user must visit ebay")
	public void user_must_visit_ebay() throws Exception {
	   p.launch();	
	   
	}

	@When("user must serach for mobile")
	public void user_must_serach_for_mobile(io.cucumber.datatable.DataTable dataTable) {
	    List<String> list = dataTable.asList();
	    e.setSearchMobile(list.get(0));
	    }

	@When("user must click on first product")
	public void user_must_click_on_first_product() {
	   e.setclickOnMobile();
	}

	@Then("user must verify buynow button is enabled")
	public void user_must_verify_buynow_button_is_enabled() {
	 e.setverifyBuynow();
	}



}
