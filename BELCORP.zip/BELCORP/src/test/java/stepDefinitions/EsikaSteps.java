package stepDefinitions;

import java.util.List;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.datatable.DataTable;
import pageobjects.EsikaPom;
import platforms.PortalPlatform;

public class EsikaSteps {
	PortalPlatform p=new PortalPlatform();
	
	GenericClass g=new GenericClass();
	EsikaPom e=new EsikaPom();
	
	
	@Given("user must go to belcorp website")
	public void user_must_go_to_belcorp_website() throws Exception {
	    p.launch();
	    e.setclickEsika();
	}

	@When("user must click on ligne shampoo")
	public void user_must_click_on_ligne_shampoo() {
	    e.setClickShampoo();
	
	}

	@When("user must click on addto cart and checkout")
	public void user_must_click_on_addto_cart_and_checkout() {
	   
	e.setClickAddToCart();
	}

	@When("user must enter name and lastname and email and confirmemail")
	public void user_must_enter_name_and_lastname_and_email_and_confirmemail(DataTable dataTable) {
	   e.setEnterDetails(dataTable);
	   
	}


	@Then("verify the checkout page")
	public void verify_the_checkout_page() {
	e.setVerifyOrder();    
	}



}
