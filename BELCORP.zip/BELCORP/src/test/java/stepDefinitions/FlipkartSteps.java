package stepDefinitions;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.support.ui.WebDriverWait;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.FlipkartPom;
import platforms.PortalPlatform;

public class FlipkartSteps extends GenericClass{
	PortalPlatform b=new PortalPlatform();
	FlipkartPom f=new FlipkartPom();
	

@Given("user must be present in flipkart website.")
public void user_must_be_present_in_flipkart_website(io.cucumber.datatable.DataTable dataTable) throws Exception {
	Map<String,String> m=dataTable.asMap(String.class, String.class);
	
    b.launch();
    Thread.sleep(2000);
    f.setLogin(m.get("username"),m.get("password"));
    f.setClose();
}

@When("user search for samsung mobile in search tab.")
public void user_search_for_samsung_mobile_in_search_tab(io.cucumber.datatable.DataTable dataTable) {
    List<String> list = dataTable.asList();
    f.setsearchSamsung(list.get(0));
}

@When("user click on the first mobile showing.")
public void user_click_on_the_first_mobile_showing() {
	
	f.setclickSamsung();
	
	
}

@Then("user order that mobile.")
public void user_order_that_mobile() {
	
	
	f.setbuyNow();
	
}
@When("user search for apple mobile in search tab.")
public void user_search_for_apple_mobile_in_search_tab() {
   f.setsearchApple("apple mobile");
}



}
