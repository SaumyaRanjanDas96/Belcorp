package stepDefinitions;

import java.awt.AWTException;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.LebelPom;
import platforms.PortalPlatform;

public class LebelSteps {
	PortalPlatform p=new PortalPlatform();
	
	GenericClass g=new GenericClass();
	LebelPom l=new LebelPom();
	

	
	@Given("user must go to belcorp site")
	public void user_must_go_to_belcorp_site() throws Exception {
	p.launch();	   
	
	}

	@When("user must click on lebel module")
	public void user_must_click_on_lebel_module() {
	    l.setClickLebel();
	}

	@When("user must click on fragrance")
	public void user_must_click_on_fragrance() throws AWTException {
	    l.setClickfragrance();
	    l.setClickBluePerfume();
	}

	@When("user must click on blue perfume")
	public void user_must_click_on_blue_perfume() throws AWTException {
	   
		l.setClickBluePerfume();
	}

	@Then("validate comments")
	public void validate_comments() {
	    l.setPrintUserandComments();
	}


}
