package stepDefinitions;

import commonUtilities.GenericClass;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.PurchaseAsGoogleUser;
import platforms.PortalPlatform;

public class PurchaseAsGoogleUserSteps extends GenericClass {
	PortalPlatform p=new PortalPlatform();
	PurchaseAsGoogleUser pa=new PurchaseAsGoogleUser();
	
	
	@Given("user must login as existing user")
	public void user_must_login_as_existing_user(io.cucumber.datatable.DataTable data) throws Exception {
	p.launch();
	pa.login(data);
	}

	@When("user must click on particular category")
	public void user_must_click_on_particular_category() {
	pa.clickProduct();  
	}
	


	@When("usermust add to cart particular product")
	public void usermust_add_to_cart_particular_product() {
	pa.clickAddtoCart();    
	}
	@Then("user must verify the catalog and offer price")
	public void user_must_verify_the_catalog_and_offer_price() {
	    pa.veifyCatalogAndOfferPrice();
	}



}
