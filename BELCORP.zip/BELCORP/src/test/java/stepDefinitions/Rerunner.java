package stepDefinitions;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import commonUtilities.ReportClass;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="@rerun/failed_scenarios.txt",
glue="stepDefinitions",
monochrome=true, 
plugin = {"pretty","json:src\\test\\resources\\Reports\\cucumber.json",
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
		},

dryRun = false)
public class Rerunner {
	@AfterClass
    public static void generateReport() {
		
		ReportClass.jvmReport(System.getProperty("user.dir")+"/src/test/resources/Reports/cucumber.json");
    }
}
