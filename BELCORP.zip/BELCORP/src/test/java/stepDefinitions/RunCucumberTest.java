package stepDefinitions;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import commonUtilities.ReportClass;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources", glue = "stepDefinitions", monochrome = true, plugin = { "pretty",
		"json:src\\test\\resources\\Reports\\cucumber.json", "timeline:test-output-thread/",
		"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:", "rerun:rerun/failed_scenarios.txt" },
		// tags = { "@RegressionMCP" },
		// tags = { "@SecurityFrameWorkLibraryAgent" },
		tags = { "@Cyzon_SB2Checkout" },
		dryRun = false
// , junit = "--step-notifications"
)
public class RunCucumberTest {

	@AfterClass
	public static void generateReport() {

		ReportClass.jvmReport(System.getProperty("user.dir") + "/src/test/resources/Reports/cucumber.json");
	}

}
