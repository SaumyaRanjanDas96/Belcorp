$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([
  {
    "id": "to-buy-product;to-buy-product-by-adding-it-to-cart-and-verify-required-fields",
    "feature": "To buy product",
    "scenario": "To buy product by adding it to cart and verify required fields",
    "start": 113205286,
    "end": 113696583,
    "group": 1,
    "content": "",
    "className": "failed",
    "tags": "@cyzon_sb2,@cyzon_sb2checkout,"
  }
]);
CucumberHTML.timelineGroups.pushArray([
  {
    "id": 1,
    "content": "Thread[main,5,main]"
  }
]);
});